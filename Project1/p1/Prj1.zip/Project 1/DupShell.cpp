/*DupShell extends the previous shell programs and is able to use commands that include pipe ("|") 
KNOWN BUGS:
-Normal commands input such as "ls" or "ls -l" no longer work properly.
-When using the command "ls -l | wc", the program will run it then return to initial sate. The output of the command is only seen after exitting the program
Coded by Jonathan Ung
*/

#include <stdio.h>
#include <string.h>
#include <iostream>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sstream>

using namespace std;

bool testCommand(string command) {
	std::string list[] = {"ls","date","more", "wc"}; //list of valid terminal commands
	bool ans = false; //init default bool variable
	for (int i = 0; i < sizeof(list)/sizeof(list[0]); i++) {
		if (list[i].compare(command)==0) { //check if user input is a valid command from list
			ans = true; //set bool ans to true
		}
	}
	return ans;
}

int main() {
 string command = "";
 pid_t pid;
 pid_t pid1;
 int pipefds[2];

 while ( command.compare("exit") != 0) {
	cout << "DupShell>";
 	getline (cin, command);
	size_t pos = command.find(' ');
	string str = "";
	str.append(command.substr(0,pos)); //grabs the first word of input assumed to be command
	bool isCommand = testCommand(str); //send command to see if it is a valid command or has been implemented yet
	bool test = false;
 if (command.compare("exit")!=0) {
	if (isCommand) { //valid command entered
		int pos = 0;
		const char * word = strtok((char*)command.c_str(), " ");;
		char* arg1[5] = {}; //command input before pipe "|"
		char* arg2[5] = {}; //command input after pipe "|"
		while (word) { //found while loop set up online to read words in a string seperated by a space
			if (strcmp(word, "|") == 0) { //if the pipe is read
				test = true;
				pos = 0;
				word = strtok(NULL, " ");
			}
			if (test == false) { //before the pipe in input
				arg1[pos] = (char*)word;
				pos++;
				word = strtok(NULL," ");
			} else { //after the pipe in input
				arg2[pos] = (char*)word;
				pos++;
				word = strtok(NULL, " ");
			}
		}
		pipe(pipefds);
		pid = fork();
		if (pid < 0) {
			cout << "Error";
		} else if (pid == 0) {
			close(pipefds[0]);
			dup2(pipefds[1],STDOUT_FILENO);
			close(pipefds[1]);
			execvp(arg1[0], arg1);
		} else {
			pid1 = fork();
			if (pid1 < 0) {
				cout << "Error";
			} else if (pid1==0) {
				close(pipefds[1]);
				dup2(pipefds[0],STDIN_FILENO);
				close(pipefds[0]);
				execvp(arg2[0], arg2);
				//wait(NULL);
				//exit(0);
			}
			else if (pid1>0) {
				wait(NULL);
			} 
		}
  	} //end of if-statement
	else { cout << "Sorry, invalid command or command currently not yet implemented!\n"; } //invalid command entered
  }else break;
 }//end of while loop
 cout << "Exiting...\n";
 exit(0);
}


