//Program iterates through the file and searches for + or -
//Program extracts the number that follows these symbols
//Decides whether to print 0 or 1 based on the symbols
//+ for 1 and - for 0
//Prints all results to the destination file defined by the user

#include <stdio.h>
#include <regex.h>

void myDecompress(FILE *out, int charCount, char indicator) {
    if(indicator == '+') {
        for(int i = 0; i < charCount; i++) {
            putc('1', out);
        }
    }

    else if(indicator == '-') {
        for(int i = 0; i < charCount; i++) {
            putc('0', out);
        }
    }
}

int main(int argc, char **argv) {
    FILE *file;
    FILE *output;
    int c, n;
    int charCount;
    int count = 0;
    int currentNum;
    char currentChar;
    char lastChar = ' ';
    char startFilePath[4096];
    char destFilePath[4096];

    printf("Enter compressed file path: ");
    scanf("%s", startFilePath);

    //get path of file being written to
    printf("Enter destination file path: ");
    scanf("%s", destFilePath);

    //open the first file to read from it and second to write to it
    file = fopen(startFilePath, "r");
    output = fopen(destFilePath, "w");

    if(file){
        while((c = fgetc(file)) != EOF) {
            currentChar = c;
            printf("%c", currentChar);

            if(currentChar == '+') {
                myDecompress(output, count, lastChar);
            }

            else if(currentChar == '-') {
                myDecompress(output, count, lastChar);
            }

            else {
                for(int i = 0; i < count; i++) {
                    putc(lastChar, output);
                }
            }
        }

        lastChar = currentChar;
    }

    fclose(output);
}
