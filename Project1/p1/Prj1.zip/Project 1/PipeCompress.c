#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/uio.h>
#include<sys/wait.h>
#include <sys/stat.h>
/*
This program makes use of fork and pipe to read from a source and write to a destination.
The parent waits for the child to read the file and closes it's end.
The parent opens the pipe to access the buffer after the parent writes into the destination and closes its end.






*/
// in this code, I used stackoverflow, the powerpoint, and geeksforgeeks.org
//specifically https://www.geeksforgeeks.org/c-program-demonstrate-fork-and-pipe/ to help my understanding of those
int main(int argc, char *argv[])
{
	FILE *file;
	FILE *output;
	int pipe[2];  // Used to store two ends of first pipe
	pid_t p;
	int c;
	int count = 0;
	char buff[4096];
	char firstNum;
	char startFilePath[4096];
	char destFilePath[4096];
	char currentChar;
	char lastChar = ' ';

	p = fork();

	if (p < 0)
	{
		fprintf(stderr, "Error");
		exit(1);
	}


	// Parent process 
	else if (p > 0)
	{
		close(pipe[0]);  // Close reading end of first pipe 
		FILE *file = fopen(argv[1], "r");
		if (file) {

			while ((c = fgetc(file)) != EOF) {
				currentChar = c;
				printf("%c", currentChar);

				//test current char
				if (currentChar != lastChar) {
					if (count >= 16) {
						myCompress(output, count, lastChar);
					}


					//puts the character into the destination file
					else {
						for (int i = 0; i < count; i++) {
							putc(lastChar, output);
						}
					}

					count = 0;
				}
				//increase the count if same
				count++;
				lastChar = currentChar;
			}

			if (count != 0) {
				if (count >= 16) {
					myCompress(output, count, lastChar);
				}

				else {
					for (int i = 0; i < count; i++) {
						putc(lastChar, output);
					}
				}
			}


		}

		fclose(output);
		close(pipe[1]);

		// Wait for child to send a string 
		wait(NULL);

		// Read string from child, print it and close 
		// reading end. 

	}
	else {
		//child
		close(pipe[1]);  // Close writing end of first pipe 


		// Read a string
		while ((c = fgetc(file)) != EOF) {
			currentChar = c;
			printf("%c", currentChar);

			// Close both reading ends 
			close(pipe[0]);


			exit(0);
		}
	}
}


void myCompress(FILE *out, int sameCharCount, char lastRead) {
	if (sameCharCount >= 16) {
		if (lastRead == '0') {
			putc('-', out);
			fprintf(out, "%d", sameCharCount);
			putc('-', out);
		}

		else if (lastRead == '1') {
			putc('+', out);
			fprintf(out, "%d", sameCharCount);
			putc('+', out);
		}
	}
}





