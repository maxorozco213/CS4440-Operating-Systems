#include<pthread.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/uio.h>
#include<sys/wait.h>
#include <sys/stat.h>
/*
By Tony Truong
The purpose of this code is to split a file into n number of pieces. Where n is given by the user.	
The program then creates forks equal to n. By delegating smaller chunks of the text to many children,
it should be faster than if it were one.

*/


//I this code I used stackoverflow and the powerpoint
int sum;


int main(int argc, char *argv[]) {

	int fd1, fd2;
	pthread_t tid;

	pid_t Fpid;
	FILE *file;
	FILE *output;
	int forkCounter = 0;
	char startFilePath[4096];
	char destFilePath[4096];
	int divis;
	//get path of file to be compressed
	printf("Enter starting file path: ");
	scanf("%s", startFilePath);
	//get path of file being written to
	printf("Enter destination file path: ");
	scanf("%s", destFilePath);
	//get path of file being written to
	printf("Enter how many divisions: ");
	scanf("%d", divis);
	Pthread_t tid[divis];
	fd1 = fopen(startFilePath, "r");
	fd2 = fopen(destFilePath, "w");
	Fpid = fork();
	//increase number of forks
	forkCounter++;
	//ppt
	for (int i = 0; i < divis; i++) {
		if ((pids[i] = fork()) < 0) {
			//
		}
		else if (pids[i] == 0) {
			//
		}
	}
}



