/*This program uses MyCompress and asks the user for an input file and destination file to compress the input file using the fork function and write the output to the entered output file */
#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>

int main() {
  pid_t pid;
  char executable[100];

    pid = fork();

    //PID will be -1 if it fails
    if (pid < 0) {
      fprintf(stderr, "Fork Failed");
      return 1;
    }

    //Child process, scheduler has PID 0
    else if (pid == 0) {
      printf("This is child\n");
      printf("Enter path to executable: ");
      scanf("%s", executable);
        //opens executable at given path
      execl(executable, (char*) NULL);
        //only runs if execl fails
      printf("Process not started.");
    }

    else {
      printf("This is parent\n");
        //waits for child to finish then continues
      wait(NULL);
      printf("\nChild Complete\n");
    }

    return 0;
}
