/*MiniShell is a program that accepts argument-less commands and execute them 
Coded by Jonathan Ung*/
#include <stdio.h>
#include <string.h>
#include <iostream>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

using namespace std;

bool testCommand(string command) {
	std::string list[] = {"ls","date"}; //list of valid terminal commands
	bool ans = false; //init default bool variable
	for (int i = 0; i < sizeof(list)/sizeof(list[0]); i++) {
		if (list[i].compare(command)==0) { //check if user input is a valid command from list
			ans = true; //set bool ans to true
		}
	}
	return ans;
}

int main() {
 string command = "";
 int pid;

 while ( command.compare("exit") != 0) {
	cout << "MiniShell>";
 	getline (cin, command);
	bool isCommand = testCommand(command); //sends command to see if it is a valid command
   if (command.compare("exit")!=0) {
	if (isCommand) { //valid command entered
		char* C = (char*)command.c_str();
		char* arg2[] = {C,NULL};
		pid = fork();
		if (pid < 0) {
			cout << "Error";
		} else if (pid == 0) {
			execvp (arg2[0], arg2);
		} else wait(NULL);
	} else { cout << "Invalid command or command not yet implemented\n"; } //error message displayed
      } else break; //exit command entered
 } //end of while loop
 cout << "Exiting...\n";
 exit(0);
}//end of class
