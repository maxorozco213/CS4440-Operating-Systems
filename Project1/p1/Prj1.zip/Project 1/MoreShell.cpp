/*MoreShell is an upgrade of the MiniShell program that is able to perform commands and arguments 
Coded by Jonathan Ung*/
#include <stdio.h>
#include <string.h>
#include <iostream>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sstream>

using namespace std;

bool testCommand(string command) {
	std::string list[] = {"ls","date","more"}; //list of valid terminal commands
	bool ans = false; //init default bool variable
	for (int i = 0; i < sizeof(list)/sizeof(list[0]); i++) {
		if (list[i].compare(command)==0) { //check if user input is a valid command from list
			ans = true; //set bool ans to true
		}
	}
	return ans;
}

int main() {
 string command = "";
 int pid;

 while ( command.compare("exit") != 0) {
	cout << "MoreShell>";
 	getline (cin, command);
	size_t pos = command.find(' ');
	string str = "";
	str.append(command.substr(0,pos)); //grabs first word of input assumed to be the command
	bool isCommand = testCommand(str); //sends command to see if it is a valid command
 if (command.compare("exit")!=0) {
	if (isCommand) { //valid command entered
		int pos = 0;
		const char * word = strtok((char*)command.c_str(), " ");;
		char* arg1[5] = {};
		while (word) { //found while loop set up online to read words in a string seperated by a space
			arg1[pos] = (char*)word;
			pos++;
			word = strtok(NULL," ");
		}
		pid = fork();
		if (pid < 0) {
			cout << "Error";
		} else if (pid == 0) {
			execvp (arg1[0], arg1);
		} else wait(NULL);
  	} //end of isCommand if statement
	else { cout << "Sorry, invalid command or command currently not yet implemented!\n"; } //invalid command entered
  }else break;
 }//end of while loop
 cout << "Exiting...\n";
 exit(0);
}


